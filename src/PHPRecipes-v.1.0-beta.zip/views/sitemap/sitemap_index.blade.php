{!! '<' . '?' . "xml version='1.0' encoding='UTF-8'?>" !!}
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
@foreach($arr_sub as $key => $submap)
<sitemap>
  <loc>{{home_url($submap)}}</loc>
</sitemap>
@endforeach
</sitemapindex>